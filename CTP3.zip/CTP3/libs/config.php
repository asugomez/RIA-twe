<?php

// Hebergement local
$BDD_host="localhost";
$BDD_user="admin";
$BDD_password="Asuncion!2020"; // vide sous windows
$BDD_base="chat-api";

?>
